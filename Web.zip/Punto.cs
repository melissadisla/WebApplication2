﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2
{
    public class Punto
    {
        public int ID { get; set; }
        public DateTime time { get; set; }
        public Double value { get; set; }
    }
}